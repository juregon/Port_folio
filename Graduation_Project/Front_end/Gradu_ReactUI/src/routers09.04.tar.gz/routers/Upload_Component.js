import React from 'react';
import '../css/Body.css';

const Upload_Component = () => {
	return(
		<div className="body_main">
            <div className="body_head">
            Upload_Component
            </div>

            
        </div>
	);
};

export default Upload_Component;