import React from 'react';
import '../css/Body.css';

class Upload_File extends React.Component {
	constructor(props) {
	    super(props);
	    this.state = {file: '',imagePreviewUrl: ''};
	  }

	  _handleSubmit(e) {
	    e.preventDefault();
	    // TODO: do something with -> this.state.file
	    console.log('handle uploading-', this.state.file);
	  }

	  _handleImageChange(e) {
	    e.preventDefault();

	    let reader = new FileReader();
	    let file = e.target.files[0];

	    reader.onloadend = () => {
	      this.setState({
	        file: file,
	        imagePreviewUrl: reader.result
	      });
	    }

	    reader.readAsDataURL(file)
	  }
	render(){
	return(
		<div className="body_main">
            <div className="body_head">
            Upload_File
            </div>
            <div className="body_head2">
            <form action="/fileUpload" onSubmit={(e)=>this._handleSubmit(e)} method="post" enctype="multipart/form-data">
	          <input className="fileInput" 
	            type="file" 
	            onChange={(e)=>this._handleImageChange(e)} />
	          <button className="submitButton" 
	            type="submit" 
	            onClick={(e)=>this._handleSubmit(e)}>Upload Image</button>
	        </form>
	        </div>
            <div>
              <table className="list_table">
                <tr className="first_tr">
                  <th>JOB NAME</th>
                  <th>STATUS</th>
                  <th>DATE</th>
                  <th>DESCRIPTION</th>
                </tr>
                <tr className="second_tr">
                  <td>job1</td>
                  <td>running</td>
                  <td>2017/7/14</td>
                  <td>1</td>
                </tr>
                <tr className="second_tr">
                  <td>job2</td>
                  <td>running</td>
                  <td>2017/7/15</td>
                  <td>2</td>
                </tr>
                <tr className="second_tr">
                  <td>job3</td>
                  <td>pending</td>
                  <td>2017/7/18</td>
                  <td>3</td>
                </tr>
                <tr className="second_tr">
                  <td>job4</td>
                  <td>pending</td>
                  <td>2017/7/18</td>
                  <td>4</td>
                </tr>
               </table>
            </div>
          </div>
	);
}
};

export default Upload_File;