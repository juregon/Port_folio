import React from 'react';
import '../css/Body.css';

const Upload_ImageBuild = () => {
	return(
		<div className="body_main">
            <div className="body_head">
            Upload_Image Build
            </div>

            
        </div>
	);
};

export default Upload_ImageBuild;